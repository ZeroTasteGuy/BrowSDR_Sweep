/*
 * SPDX-FileCopyrightText: 2015-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once

#include "esp_err.h"
#include "esp_vfs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/* TODO IDF-14810:  Rename so esp_console does not appear in the name. */
/**
 * @brief Parameters for console device: USB CDC
 *
 * @note It's an empty structure for now, reserved for future
 *
 */
typedef struct esp_console_dev_usb_cdc_config {

} esp_console_dev_usb_cdc_config_t;

/**
 * @brief add /dev/cdcacm virtual filesystem driver
 *
 * This function is called from startup code to enable console output
 */
esp_err_t esp_vfs_dev_cdcacm_register(void);

/**
 * @brief Set the line endings expected to be received
 *
 * This specifies the conversion between line endings received and
 * newlines ('\n', LF) passed into stdin:
 *
 * - ESP_LINE_ENDINGS_CRLF: convert CRLF to LF
 * - ESP_LINE_ENDINGS_CR: convert CR to LF
 * - ESP_LINE_ENDINGS_LF: no modification
 *
 * @note this function is not thread safe w.r.t. reading
 *
 * @param mode line endings expected
 */
void esp_vfs_dev_cdcacm_set_rx_line_endings(esp_line_endings_t mode);

/**
 * @brief Set the line endings to sent
 *
 * This specifies the conversion between newlines ('\n', LF) on stdout and line
 * endings sent:
 *
 * - ESP_LINE_ENDINGS_CRLF: convert LF to CRLF
 * - ESP_LINE_ENDINGS_CR: convert LF to CR
 * - ESP_LINE_ENDINGS_LF: no modification
 *
 * @note this function is not thread safe w.r.t. writing
 *
 * @param mode line endings to send
 */
void esp_vfs_dev_cdcacm_set_tx_line_endings(esp_line_endings_t mode);

#ifdef __cplusplus
}
#endif
